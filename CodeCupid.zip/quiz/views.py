from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from .models import Project
from .forms import QuizForm, ProjectSearchForm

def quiz_view(request):
    if request.method == 'POST':
        form = QuizForm(request.POST)
        if form.is_valid():
            skill_level = form.cleaned_data['skill_level']
            hobbies = form.cleaned_data['hobbies']
            languages = form.cleaned_data['languages']

            matched_projects = Project.objects.filter(skill_level=skill_level, language__in=languages)

            return render(request, 'quiz/results.html', {'projects': matched_projects})
    else:
        form = QuizForm()

    return render(request, 'quiz/quiz.html', {'form': form})

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('dashboard')
    else:
        form = UserCreationForm()

    return render(request, 'signup.html', {'form': form})

def project_search(request):
    if request.method == 'GET':
        form = ProjectSearchForm(request.GET)
        if form.is_valid():
            skill_level = form.cleaned_data.get('skill_level')
            project_type = form.cleaned_data.get('project_type')

            projects = Project.objects.all()

            if skill_level:
                projects = projects.filter(skill_level=skill_level)
            if project_type:
                projects = projects.filter(category=project_type)

            return render(request, 'quiz/search_results.html', {'projects': projects})
    else:
        form = ProjectSearchForm()

    return render(request, 'quiz/search.html', {'form': form})

@login_required
def dashboard_view(request):
    profile = request.user.profile
    recommended_projects = Project.objects.filter(skill_level=request.user.profile.skill_level)
    return render(request, 'quiz/dashboard.html', {'profile': profile, 'recommended_projects': recommended_projects})
