from django import forms
# from .models import Question, Answer, Project


class QuizForm(forms.Form):
    skill_level = forms.ChoiceField(choices=[(1, 'Beginner'), (2, 'Intermediate'), (3, 'Advanced')])
    hobbies = forms.CharField(max_length=255, help_text="What are your hobbies?")
    languages = forms.MultipleChoiceField(choices=[('python', 'Python'), ('js', 'JavaScript'), ('java', 'Java')])

class ProjectSearchForm(forms.Form):
    skill_level = forms.ChoiceField(choices=[(1, 'Beginner'), (2, 'Intermediate'), (3, 'Advanced')], required=False)
    project_type = forms.ChoiceField(choices=[('web', 'Web Development'), ('data', 'Data Science'), ('game', 'Game Development')], required=False)
