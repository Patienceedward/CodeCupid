from django.urls import path
from . import views

urlpatterns = [
    path('', views.quiz_view, name='quiz'),  # Root path for the quiz app
    path('search/', views.project_search, name='search'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
]
