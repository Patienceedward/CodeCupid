from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from quiz import views as quiz_views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('quiz.urls')),  # Include quiz URLs
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('signup/', quiz_views.signup_view, name='signup'),  # Ensure this view is defined correctly
]

# Serve static files during development
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
